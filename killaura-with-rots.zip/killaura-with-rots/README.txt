WClient Killaura + rotation engines ("rots") - trimmed set
==========================================================
KillauraModule is THE module carrying every rotation mode, so this zip
contains only it, its engine package, and its orbit helper.

KillauraModule.kt  - hosts rotation_mode enum with all 30 modes:
                     Predictive, Abysm, Auto, HvHGod, the 4 Geo patterns
                     (Circle/Square/Zigzag/Spiral), 12 Kiwi modes (Snap,
                     Normal, Silent, Body, Ping Predict, Lead Shot, Smooth,
                     Legit, Jitter, Strafe, Anticipate...) and the 11 Lynx
                     handlers below.
rots/
  KillauraRots.kt      - 11 ported Lynx/Gato handlers (Smooth, Nemesis,
                         Vortex, FrontStrafe, AirHvH Pro, FrontsX, Astral,
                         Atomic, Syntax, Cortex, Alpha)
  PredictiveAim.kt     - predictor + speed/accel-limited servo aim engine
  PredictiveRotator.kt - glue: target lock hysteresis, camera sync packets
  AbysmRot.kt          - proportional, speed-capped tracker
  HvHGod.kt            - enemy-style classifier -> picks a handler
  GeoRot.kt            - Circle/Square/Zigzag/Spiral aim-point patterns
RotationUtils.kt   - orbit/spin helper KillauraModule imports for strafing

Note: KillauraModule also imports the app's Module/GameSession/entity
framework, so it compiles as part of WClient, not standalone.
