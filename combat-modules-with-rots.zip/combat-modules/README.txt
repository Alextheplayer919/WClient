WClient combat modules + rotation engines ("rots")
==================================================
Source: app/src/main/java/com/retrivedmods/neon/game/module/combat/

/modules (root of zip):
  All combat modules (KillauraModule, AutoFight, WAura, InfiniteAura,
  EnemyHunter, AutoHvH, ACA, OrbitStrafe, TriggerBot, HitAndRun, Hitbox,
  AntiKnockback, AutoEat, AutoPot, AutoTotem, BaseConsume, HotbarSwitcher)

/rots:
  KillauraRots.kt      - 11 ported Lynx/Gato rotation handlers
                         (Smooth, Nemesis, Vortex, FrontStrafe, AirHvH Pro,
                         FrontsX, Astral, Atomic, Syntax, Cortex, Alpha)
  PredictiveAim.kt     - predictor + speed/accel-limited servo aim engine
  PredictiveRotator.kt - glue: target lock hysteresis, camera sync packets
  AbysmRot.kt          - proportional, speed-capped tracker
  HvHGod.kt            - enemy-style classifier -> picks a handler
  GeoRot.kt            - Circle/Square/Zigzag/Spiral aim-point patterns

Note: these files depend on the rest of the app (GameSession, entities,
Cloudburst protocol, module framework) - they compile as part of WClient,
not standalone.
